<?php

define('SERVER_ROOT', $_SERVER['DOCUMENT_ROOT'].'/');
//define('SERVER_ROOT', $_SERVER['DOCUMENT_ROOT'].'/web1kovacsadam/');

define('URLI', '');

//define('SITE_ROOT', 'http://pfw.ddns.net/web1kovacsadam/');
define('SITE_ROOT', '');


require_once(SERVER_ROOT . 'controllers/' . 'router.php');

?>