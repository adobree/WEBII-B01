<?php

class Eloadas_Model
{
	public function get_data($vars)
    {
		
	}
	
}
