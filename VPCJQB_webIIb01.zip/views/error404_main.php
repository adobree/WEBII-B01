<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo SITE_ROOT?>css/error.css">
</head>
<h2> <br>A kért oldal nem létezik!<br> </h2>
<div class="error">404</div>
