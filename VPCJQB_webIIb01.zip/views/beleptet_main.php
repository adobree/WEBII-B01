<body class="log_background">
<h2><br><?= $viewData['uzenet']?><br></h2>
</body>