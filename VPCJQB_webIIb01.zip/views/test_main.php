<h2> Requested data: </h2>
<h4> <?=$viewData['title']?> </h4>
<p> <?=$viewData['content']?> </p>