<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" type="text/css" href="<?php echo SITE_ROOT ?>css/nyito.css">
</head>

<body>
  <div class="main">
    <div class="cim">
      Lorem ipsum dolor sit amet.
    </div>
    <div class="section-1">
      <p class="text">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores dicta maxime, quos qui eligendi fuga placeat nobis labore quaerat voluptatibus earum vero tempore animi esse quae sed minus excepturi ad.<br>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellat laborum quia, nesciunt neque dolores incidunt maiores ea eaque voluptatum unde?<br>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa natus obcaecati fuga quis at aliquam facere, nisi, unde nulla pariatur veritatis iste magni optio iusto quo, libero animi. Ducimus deleniti veritatis neque omnis ab reprehenderit, eum iste repudiandae ullam eos.<br>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem quo alias in velit nam quasi facilis, ullam consectetur, nihil provident minus perspiciatis architecto incidunt quae fuga dolore aperiam accusantium modi, voluptatum amet qui atque sit itaque aut! Labore, quae sequi deserunt animi nihil est officiis perferendis voluptate, dolore consequuntur excepturi.
      </p>
      <div class="image-wrapper">
        <div class="bord-rad-yt-container">
          <iframe width="570" height="315" src="https://www.youtube.com/embed/X7tIUTUSfR0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
      </div>
    </div>
    <div class="section-2">
      <p class="text">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque quae cumque provident dolore in ducimus incidunt reiciendis consequatur minima explicabo amet at ex repellat, repellendus velit aut corporis accusamus, eveniet magnam. Rem, architecto sapiente quasi dolorum ab eligendi. Harum illum totam vel, optio maxime laudantium praesentium libero cum nostrum fuga corrupti culpa sit voluptatum vero architecto delectus, pariatur reprehenderit! Harum quas in, accusamus, unde cumque officiis a molestias eos voluptatem tempora pariatur cum repellat ducimus incidunt veniam iure. Voluptate eos consequatur vero vel animi et ullam dolorum repellendus quo ducimus aspernatur nemo saepe ut iste ipsum mollitia, quasi est consequuntur. Facere odit corrupti deserunt laudantium officia et. Iure nisi eveniet earum officia dolores sed vitae soluta totam. Nemo iste veniam, quae voluptates earum, suscipit nihil tempore ratione molestiae mollitia autem rem ut enim accusamus minus, a incidunt voluptas nam porro error cupiditate provident?
    </div>
    <div class="section-3">
      <div class="image-wrapper">
        <img src="images/images01.jpeg" alt="">
      </div>
      <p class="text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum, nihil non nam temporibus porro dolorum ipsum illo quaerat. Dolorum nihil sapiente autem, consequatur doloribus eos aperiam neque cum aliquid.<br>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum consequuntur voluptas ducimus ut illo impedit repudiandae, consectetur, molestiae id accusantium sunt molestias odit, reprehenderit hic architecto ipsam quam beatae? Dolor, mollitia eius sit distinctio aperiam asperiores illo optio rerum expedita praesentium, omnis cumque. Asperiores ea, sed nostrum eius repellat illo accusamus et, aliquam magnam dignissimos amet deserunt soluta ab? Ab.</p>
    </div>
  </div>
</body>

</html>